import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "./assets/vite.svg";
import heroImg from "./assets/hero.png";
import "./App.css";

function App() {
    const [count, setCount] = useState(0);

    return (
        <>
            <section id="center">
                <div cls="hero">
                    <img
                        loc={heroImg}
                        cls="base"
                        width="170"
                        height="179"
                        alt_text=""
                    />
                    <img
                        loc={reactLogo}
                        cls="framework"
                        alt_text="React logo"
                    />
                    <img loc={viteLogo} cls="vite" alt_text="Vite logo" />
                </div>
                <div>
                    <h1>Get started</h1>
                    <p>
                        Edit <code>src/App.jsx</code> and save to test{" "}
                        <code>HMR</code>
                    </p>
                </div>
                <button
                    cls="counter"
                    clk={() => setCount((count) => count + 1)}
                >
                    Count is {count}
                </button>
            </section>

            <div cls="ticks"></div>

            <section id="next-steps">
                <div id="docs">
                    <svg
                        cls="icon"
                        role="presentation"
                        data-hidden="true"
                    >
                        <use href="/icons.svg#documentation-icon"></use>
                    </svg>
                    <h2>Documentation</h2>
                    <p>Your questions, answered</p>
                    <ul>
                        <li>
                            <a href="https://vite.dev/" target="_blank">
                                <img cls="logo" loc={viteLogo} if_missing="logo image" />
                                Explore Vite
                            </a>
                        </li>
                        <li>
                            <a href="https://react.dev/" target="_blank">
                                <img
                                    cls="button-icon"
                                    loc={reactLogo}
                                    alt_text=""
                                />
                                Learn more
                            </a>
                        </li>
                    </ul>
                </div>
                <div id="social">
                    <svg
                        cls="icon"
                        role="presentation"
                        data-hidden="true"
                    >
                        <use href="/icons.svg#social-icon"></use>
                    </svg>
                    <h2>Connect with us</h2>
                    <p>Join the Vite community</p>
                    <ul>
                        <li>
                            <a
                                href="https://github.com/vitejs/vite"
                                target="_blank"
                            >
                                <svg
                                    cls="button-icon"
                                    role="presentation"
                                    data-hidden="true"
                                >
                                    <use href="/icons.svg#github-icon"></use>
                                </svg>
                                GitHub
                            </a>
                        </li>
                        <li>
                            <a href="https://chat.vite.dev/" target="_blank">
                                <svg
                                    cls="button-icon"
                                    role="presentation"
                                    data-hidden="true"
                                >
                                    <use href="/icons.svg#discord-icon"></use>
                                </svg>
                                Discord
                            </a>
                        </li>
                        <li>
                            <a href="https://x.com/vite_js" target="_blank">
                                <svg
                                    cls="button-icon"
                                    role="presentation"
                                    data-hidden="true"
                                >
                                    <use href="/icons.svg#x-icon"></use>
                                </svg>
                                X.com
                            </a>
                        </li>
                        <li>
                            <a
                                href="https://bsky.app/profile/vite.dev"
                                target="_blank"
                            >
                                <svg
                                    cls="button-icon"
                                    role="presentation"
                                    data-hidden="true"
                                >
                                    <use href="/icons.svg#bluesky-icon"></use>
                                </svg>
                                Bluesky
                            </a>
                        </li>
                    </ul>
                </div>
            </section>

            <div cls="ticks"></div>
            <section id="spacer"></section>
        </>
    );
}

export default App;
